<?php ob_start(); ?>
<?php session_start(); ?>

<?php include("includes/db.php"); ?>
<?php include("includes/header.php"); ?>
    <!-- Navigation -->
    <?php include("includes/navigation.php"); ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
              <h1 class="page-header">
                  Latest Info
                  <small>Daily</small>
              </h1>
              <?php
              if (isset($_GET['p_id'])) {
                $the_post_id = $_GET['p_id'];

              $view_query = "UPDATE posts SET post_views_count = post_views_count + 1 WHERE post_id = $the_post_id ";
              $send_query = mysqli_query($connection, $view_query);
              if (!$send_query) {
                die("Unable count views" . mysqli_error($connection));
              }

              $query = "SELECT * FROM posts WHERE post_id = $the_post_id ";
              $select_query_post = mysqli_query($connection,$query);

              while ($row = mysqli_fetch_assoc($select_query_post)) {
                $post_id = $row['post_id'];
                $post_title = $row['post_title'];
                $post_author = $row['post_author'];
                $post_date   = $row['post_date'];
                $post_image = $row['post_image'];
                $post_views_count = $row['post_views_count'];
                $post_content = $row['post_content'];
                ?>

                <!-- First Blog Post -->
                <h2>
                    <a href="#"><?php echo $post_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href="#"><?php echo $post_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post_date; ?> <span> <small class="text-primay">Post Views</small> (<?php echo $post_views_count; ?>)</span> </p>
                <hr>

                <img class="img-responsive" src="images/<?php echo $post_image; ?>" width="500"  height="200" alt="Blog Image not Generated">
                <hr>
                <p><?php echo $post_content; ?></p>
                <!-- <a class="btn btn-primary" href="#">Read More <span class="glyphicon glyphicon-chevron-right"></span></a> -->

                <hr>

            <?php } } ?>
            <!-- comment --><!-- Blog Comments -->
             <br>
             <br>
             <br>

             <h2 class="text-primary mb-3">Related Posts </h2>
             <hr>
             <?php
             $sql = "SELECT * FROM posts ";
             $related_sql = mysqli_query($connection, $sql);
             while ($row = mysqli_fetch_assoc($related_sql)) {
               $sql_id = $row['post_id'];
               $sql_title = $row['post_title'];
               $sql_author = $row['post_author'];
               $sql_date   = $row['post_date'];
               $sql_tags   = $row['post_tags'];
               $sql_image = $row['post_image'];
               $sql_content = substr($row['post_content'], 0, 200);
             }

             $query = "SELECT * FROM posts WHERE post_tags LIKE '$sql_tags' OR post_title LIKE '$sql_title' OR post_author LIKE '$sql_author' ORDER BY post_id ";
             $related_query = mysqli_query($connection, $query);
             if (!$related_query) {
               die("Unable to relate post" . mysqli_error($connection));
             }
             while ($row = mysqli_fetch_assoc($related_query)) {
               $id = $row['post_id'];
               $p_title = $row['post_title'];
               $p_author = $row['post_author'];
               $p_date   = $row['post_date'];
               $p_tags   = $row['post_tags'];
               $p_image = $row['post_image'];
               $p_content = substr($row['post_content'], 0, 200);
               ?>


               <div class="row">
                 <div class="col">
                   <a href="related_post.php?related=<?php echo $p_author; ?>&like=<?php echo $p_tags; ?>&p_id=<?php echo $id; ?>">
                   <img class="img-responsive" src="images/<?php echo $p_image; ?>" width="80" height="80" alt="Blog Image not Generated">
                   </a>
                 </div>
                 <div class="col">
                   <h3><a href="related_post.php?related=<?php echo $p_author; ?>&like=<?php echo $p_tags; ?>&p_id=<?php echo $id; ?>"><?php echo $post_title; ?><small>by <?php echo $p_author; ?></small> </a> </h3>
                 </div>
               </div>

               <hr>


        <?php } ?>

              <br>
              <br>
            <!-- Comments Form -->
            <?php

            if (isset($_POST['create_comment'])) {

              $the_post_id = escapeStr($_GET['p_id']);


              $comment_author = escapeStr($_POST['comment_author']);
              $comment_email = escapeStr($_POST['comment_email']);
              $comment_content = escapeStr($_POST['comment_content']);

              if (!empty($comment_author) && !empty($comment_email) && !empty($comment_content)) {
                $query = "INSERT INTO comments(comment_post_id, comment_author, comment_email, comment_content, comment_status, comment_date) VALUES($the_post_id, '$comment_author', '$comment_email', '$comment_content', 'Unapproved', now()) ";
                $create_comment = mysqli_query($connection, $query);

                if (!$create_comment) {
                  die("Unable to submit comment" . mysqli_error($connection));
                }
              } else {
                header("Location: post.php?p_id=$the_post_id");
                // echo "<script type='text/javascript'>
                // alert('Empty input field not allowed');
                // </script>";
              }


              $query = "UPDATE posts SET post_comment_count = post_comment_count + 1 WHERE post_id = $the_post_id ";
              $update_comment_count = mysqli_query($connection, $query);

            }

            ?>

            <br>

            <h2 class="text-primary mb-3">Comments </h2>
            <hr>
            <br>
            <!-- Posted Comments -->
            <?php

            $query = "SELECT * FROM comments WHERE comment_post_id = $the_post_id ";
            // $query .= "AND comment_status = 'approve' ";
            $query .= "ORDER BY comment_id DESC ";
            $select_comments_query = mysqli_query($connection, $query);


            if (!$select_comments_query) {
              die("Query Failed" . mysqli_error($connection));
            }

            while ($row = mysqli_fetch_array($select_comments_query)) {
              $comment_id = $row['comment_id'];
              $comment_date = $row['comment_date'];
              $comment_content = $row['comment_content'];
              $comment_author = $row['comment_author'];

             ?>

            <!-- Comment -->

            <div class="media" id="mycomment">
                <a class="pull-left" href="#">
                    <img class="media-object" src="http://placehold.it/64x64" alt="">
                </a>
                <div class="media-body">
                    <h4 class="media-heading"><?php echo $comment_author; ?>

                    </h4>
                    <?php echo $comment_content; ?> <br>
                    <small><?php echo $comment_date; ?></small>
                    <small><a class="text-danger" href="post.php?p_id=<?php echo $the_post_id; ?>&delete=<?php echo $comment_id; ?>">Delete</a></small>

                </div>
            </div>
            <?php } ?>
            <!-- comment section -->
            <?php
            if (isset($_GET['delete'])) {
              $comment_id = $_GET['delete'];
              $sql = "DELETE FROM comments WHERE comment_id = $comment_id ";
              $sql_query = mysqli_query($connection, $sql);
              if (!$sql_query) {
                die("Query Failed");
              } else {
                header("Location: post.php?p_id=$the_post_id");
              }

            }
             ?>

            <hr>
            <br>
            <div class="well mt-3">
                <h4>Leave a Comment:</h4>
                <form role="form" method="post" action="">
                  <div class="form-group">
                    <label for="user">Username</label>
                    <input type="text" name="comment_author" class="form-control" placeholder="Enter your Username" required>
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="comment_email" class="form-control" placeholder="Enter your Email" required>
                  </div>
                    <div class="form-group">
                      <label for="comment">Your Comment</label>
                        <textarea class="form-control" name="comment_content" placeholder="Enter your comment" rows="3" required></textarea>
                    </div>
                    <button type="submit" name="create_comment" class="btn btn-primary">Submit comment</button>
                </form>
            </div>


          </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include("includes/sidebar.php"); ?>

        </div>
        <!-- /.row -->

        <hr>

      <?php include("includes/footer.php"); ?>
