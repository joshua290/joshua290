
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background: #563D7C;">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#" style="color:#FFE484;">CMS</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

            <ul class="nav navbar-nav">
                <li>
                    <a href="index.php" style="color: #FFFFFF;">Home</a>
                </li>

                <li>
                    <a href="#"  style="color: #CDBFE3;">About Us</a>
                </li>
                <li>
                    <a href="contact.php" style="color: #CDBFE3;">Contact Us</a>
                </li>
                <li>
                    <a href="registration.php" style="color: #CDBFE3;">Sign up</a>
                </li>
                <li>
                    <a href="story.php" style="color: #CDBFE3;">Post Story</a>
                </li>
                <!-- <li>
                    <a href="story.php" style="color: #CDBFE3;" data-toggle="modal" data-target="#exampleModal" data-whatever="@fat">Post Story</a>

                </li> -->

                <?php
                $query = "SELECT * FROM categories";
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                  $cat_id = $row['cat_id'];
                  $cat_Title = $row['cat_title'];
                  echo "<li><a href='category.php?category=$cat_id'>{$cat_Title}</a></li>";
                }
                 ?>
            </ul>

            <!-- search -->

            <!-- end of search -->
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav>
