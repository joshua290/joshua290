<?php
if (isset($_POST['submit_story'])) {
  $story_title = $_POST['story_title'];
  $story_author = $_POST['story_author'];
  $story_email = $_POST['story_email'];
  $story_tags = $_POST['story_tags'];
  $story_content = $_POST['story_content'];
  $story_date = date('d-m-Y');
  $story_status = "unapproved";

  $story_image = $_FILES['story_image']['name'];
  $story_image_temp = $_FILES['story_image']['tmp_name'];

  move_uploaded_file($story_image_temp, "../images/$story_image");

  if (!empty($story_title) && !empty($story_author) && !empty($story_email) && !empty($story_tags) && !empty($story_content)) {
    $query = "INSERT INTO story(story_title,story_author,story_tags,story_image,story_status,story_content,story_date) VALUES('$story_title','$story_author','$story_tags','$story_image','$story_status','$story_content','now()') ";
    $story_query = mysqli_query($connection, $query);

    if (!$story_query) {
      die("Unable to submit Story" . mysqli_error($connection));
    }
    else {
      echo "Succesfully";
    }


  }
}
 ?>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Post your Story</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="" enctype="multipart/form-data">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Post Title:</label>
            <input type="text" class="form-control" id="recipient-name" name="story_title">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Post Author:</label>
            <input type="text" class="form-control" id="recipient-name" name="story_author">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Sender's Email:</label>
            <input type="email" class="form-control" id="recipient-name" name="story_email">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Post Tags:</label>
            <input type="text" class="form-control" id="recipient-name" name="story_tags">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Post Image:</label>
            <input type="file" class="form-control" id="recipient-name" name="story_image">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Post Content:</label>
            <textarea class="form-control" id="message-text" name="story_content"></textarea>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success" name="submit_story">Submit Story</button>
      </div>
    </div>
  </div>
</div>
