<?php
function getUserById($id) {
		global $connection;
		$sql = "SELECT * FROM users WHERE id=$id LIMIT 1";

		$result = mysqli_query($connection, $sql);
		$user = mysqli_fetch_assoc($result);

		// returns user in an array format:
		// ['id'=>1 'username' => 'Awa', 'email'=>'a@a.com', 'password'=> 'mypass']
		return $user;
	}

function escapeStr($data)
{
	global $connection;
	$data = trim($data);
	$data = strip_tags($data);
	$data = htmlspecialchars($data);
	$data = htmlentities($data);
	$data = mysqli_real_escape_string($connection, $data);
	return $data;
}

function login_user() {
  global $connection;
  $username = $password = "";
  $usernameErr = $passwordErr = "";
  if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $username = mysqli_real_escape_string($connection, $username);
    $password = mysqli_real_escape_string($connection, $password);
    $password = md5($password);

    if (empty($username)) {
      $usernameErr = "Username is required!";
    }
    if (empty($password)) {
      $passwordErr = "Password is required!";
    }

    if (!empty($username) && !empty($password)) {
      $query = "SELECT * FROM users WHERE username = '$username' AND user_password = '$password' ";
      $select_login = mysqli_query($connection, $query);

      if (!$select_login) {
        die("Query Failed" . mysqli_error($connection));
      }

      if (mysqli_num_rows($select_login) == 1) {

        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: index.php');
      }else {
        echo "<div class='alert alert-danger'>
          <strong>Incorrect username or password!</strong>
          </div>";

      }


    }

  }

}



 ?>
