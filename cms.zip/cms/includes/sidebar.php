<div class="col-md-4">
 <?php
   ?>
    <!-- Blog Search Well -->
    <div class="well">
        <h4>Blog Search</h4>
        <form class="" action="search.php" method="post">
        <div class="input-group">
            <input type="text" name="search" class="form-control">
            <span class="input-group-btn">
                <button name="submit" class="btn btn-default" type="submit">
                    <span class="glyphicon glyphicon-search"></span>
            </button>
            </span>
        </div>
        <!-- /.input-group -->
        </form>
        <!-- end of form -->
    </div>

    <div class="well">
        <h4>Login</h4>
        <form action="includes/login.php" method="post">
        <div class="form-group">
            <input type="text" placeholder="Enter Username" name="username" class="form-control" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Enter Password" class="form-control">
            <span class="input-group-btn">
                <button name="login" class="btn btn-primary" type="submit">
                    Login
            </button>
            </span>
        </div>
        <!-- /.input-group -->
        </form>
        <!-- end of form -->
    </div>





    <!-- Blog Categories Well -->
    <div class="well">
        <h4>Blog Categories</h4>
        <?php
        $query = "SELECT * FROM categories";
        $cat_result = mysqli_query($connection, $query);
         ?>

        <div class="row">
            <div class="col-lg-12">
                <ul class="list-unstyled">
                  <?php
                  while ($row = mysqli_fetch_assoc($cat_result)) {
                    $cat_id = $row['cat_id'];
                    $cat_title = $row['cat_title'];
                    echo "<li><a href='category.php?category=$cat_id'>{$cat_title}</a></li>";
                  }
                   ?>
                </ul>
            </div>
            <!-- /.col-lg-6 -->
       </div>
        <!-- /.row -->
    </div>

    <!-- Side Widget Well -->
    <div class="well">
        <h4>Blog Statistics</h4>
        <?php
        $user_sql = "SELECT * FROM users ";
        $check_sql = mysqli_query($connection, $user_sql);
        $count_sql = mysqli_num_rows($check_sql);

        $post_sql = "SELECT * FROM posts ";
        $check_post = mysqli_query($connection, $post_sql);
        $count_post = mysqli_num_rows($check_post);
         ?>
        <p><strong>Date: </strong> <?php echo date("d-m-Y"); ?><br>
          <strong>Total Users: </strong><?php echo $count_sql . " Users"; ?> <br>
        <strong>Total Posts: </strong><?php echo $count_post; ?> <br>
        <strong>Public Stories: </strong> <br>
        <strong><a href="#">Post Your Story: </a></strong><br>
       </p>
    </div>

</div>
