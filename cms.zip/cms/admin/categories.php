<?php include("includes/admin_header.php"); ?>
    <div id="wrapper">

    <!-- Navigation -->
    <?php include("includes/admin_navigation.php"); ?>
    <!-- end of navigation -->
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                      <br><br>
                        <h1 class="page-header">
                            Categories
                            <small>page</small>
                        </h1>
                        <div class="col-xs-6">

                          <form class="" action="" method="post">
                            <div class="form-group">
                              <br>
                              <label for="cat-title">Add Category</label>
                              <br>
                              <?php createCategory(); ?>
                              <input type="text" id="cat-title" class="form-control" name="cat_title" placeholder="Enter Category title">
                            </div>
                            <div class="form-group">
                              <button type="submit" class="btn btn-primary" name="submit">Add Category</button>
                            </div>
                          </form>
                          <!-- retrieving the update column -->

                          <?php update(); ?>

                        </div>
                        <!-- end of form categories -->
                        <div class="col-xs-6">
                          <div class="table-responsive">
                          <table class="table table-borderless table-striped">
                            <thead>
                              <tr>
                                <th>ID</th>
                                <th>Category Title</th>
                              </tr>
                            </thead>
                            <tbody>
                              <!-- php for reading categories -->
                              <?php readCategory(); ?>
                              <?php deleteCategory(); ?>
                            </tbody>
                          </table>
                          </div>
                        </div>



                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->
        <?php include("includes/admin_footer.php"); ?>
