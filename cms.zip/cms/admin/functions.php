<?php
function format_text($text) {
	$message = str_replace(array('&amp;quot;', '</n>'), array('"', "'"), $text);

	return $message;
}

function escapeString($data) {
	global $connection;
  $data = trim($data);
  $data = stripslashes($data);
  $data = strip_tags($data);
  $data = htmlspecialchars($data);
  $data = htmlentities($data);
  $data = mysqli_real_escape_string($connection, $data);
  return $data;
}

function users_online() {
  global $connection;
  $session = session_id();
  $time = time();
  $time_out_in_seconds = 30;
  $time_out = $time - $time_out_in_seconds;

  $query = "SELECT * FROM users_online WHERE session = '$session' ";
  $send_query = mysqli_query($connection, $query);
  $count = mysqli_num_rows($send_query);

  if ($count = 0) {
    $query = "INSERT INTO users_online(session, session_time) VALUES('$session', '$time') ";
    $cnt_query = mysqli_query($connection, $query);
    if (!$cnt_query) {
      die("Function failed");
    }
  } else {
    mysqli_query($connection, "UPDATE users_online SET session_time = '$time' WHERE session = '$session' ");
  }
  $users_online_query = mysqli_query($connection, "SELECT * FROM users_online WHERE session_time > $time_out ");
  $count_user = mysqli_num_rows($users_online_query);
  return $count_user;
}

function createCategory() {
  if (isset($_POST['submit'])) {
    global $connection;
    if (empty($_POST['cat_title'])) {
      echo "<div class='alert alert-danger'>";
      echo "<strong>Category title is required!</strong>";
      echo "</div>";
    } else {
      $cat_title = $_POST['cat_title'];
      $query = "INSERT INTO categories(cat_title) ";
      $query .= "VALUE('{$cat_title}') ";

      $create_cat = mysqli_query($connection, $query);

      if ($create_cat) {
        echo "<div class='alert alert-success'>";
        echo "<strong>Category added Succesfully!</strong>";
        echo "</div>";
      } else {
        die("Query failed" . mysqli_error($connection));
      }
    }
  }

}

function readCategory() {
  global $connection;
  // reading categories
  $query = "SELECT * FROM categories";
  $select_category = mysqli_query($connection, $query);
  // looping Category
  while ($row = mysqli_fetch_assoc($select_category)) {
    $cat_id = $row['cat_id'];
    $cat_title = $row['cat_title'];
    echo "<tr>";
    echo "<td>{$cat_id}</td>";
    echo "<td>{$cat_title}</td>";
    echo "<td><a class='text-danger' href='categories.php?delete={$cat_id}'>Delete</a></td>";
    echo "<td><a class='text-success' href='categories.php?edit={$cat_id}'>Edit</a></td>";
    echo "</tr>";
  }

}
function deleteCategory() {
  global $connection;
  if (isset($_GET['delete'])) {
    $the_cat_id = $_GET['delete'];
    $query = "DELETE FROM categories WHERE cat_id = {$the_cat_id} ";
    $delete_query = mysqli_query($connection, $query);

    if ($delete_query) {
      header("Location: categories.php");
    }
  }
}

function update() {
  global $connection;
  if (isset($_GET['edit'])) {
    $cat_id = $_GET['edit'];
    include("includes/update_categories.php");
  }
}
 ?>
