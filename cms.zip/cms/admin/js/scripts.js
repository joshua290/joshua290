tinymce.init({selector:'textarea'});
