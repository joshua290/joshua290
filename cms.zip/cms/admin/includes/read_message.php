<?php
if (isset($_GET['p_id'])) {
  $the_msg_id = $_GET['p_id'];
}
$query = "SELECT * FROM messages WHERE msg_id = $the_msg_id ";
$select_msgs_by_id = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($select_msgs_by_id)) {
  $msg_id = $row['msg_id'];
  $fullname = $row['full_name'];
  $s_phone = $row['phone_num'];
  $email = $row['msg_email'];
  $subject = $row['msg_subject'];
  $msg_body = $row['msg_body'];
  $msg_date = $row['msg_date'];

}
?>

<div class="container-fluid">
  <div class="tab-content">
    <div class="tab-pane active">
      <div class="row">
        <div class="col-md-4">
          <div class="panel panel-default panel-fill">
            <div class="panel-heading">
              <h3 class="panel-title">Personal information</h3>
            </div>

            <div class="panel-body">
              <div class="m-b-20">
                <strong>Full Name</strong>
                <br>
                <p class="text-muted"><?= $fullname ?></p>
              </div>

              <div class="m-b-20">
                <strong>E-mail</strong>
                <br>
                <p class="text-muted"><?= $email ?></p>
              </div>

              <div class="m-b-20">
                <strong>Phone Number</strong>
                <br>
                <p class="text-muted"><?= $s_phone ?></p>
              </div>

              <div class="m-b-20">
                <strong>Date</strong>
                <br>
                <p class="text-muted"><?= $msg_date ?></p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-8">
          <div class="panel panel-default panel-fill">
            <div class="panel-heading">
              <h3 class="panel-title">Message</h3>
            </div>
            <div class="panel-body">
              <h4 class="font-14 mb-3 text-uppercase text-center"><?= $subject ?></h4>
              <p><?= format_text($msg_body) ?></p>
            </div>
          </div>
        </div>




      </div>
    </div>
  </div>
</div>
