<?php include("delete_modal.php"); ?>
<div class="table-responsive">
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Subject</th>
        <th>Date</th>
        <!-- <th>Approve</th> -->
        <!-- <th>Unapprove</th> -->
        <th>...</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $query = "SELECT * FROM messages ORDER BY msg_id DESC ";
      $posts_query_msgs = mysqli_query($connection, $query);

      while ($row = mysqli_fetch_assoc($posts_query_msgs)) {
        $msg_id = $row['msg_id'];
        $fullname = $row['full_name'];
        $s_phone = $row['phone_num'];
        $email = $row['msg_email'];
        $subject = $row['msg_subject'];
        $msg_body = $row['msg_body'];
        $msg_date = $row['msg_date'];

        echo "<tr>";
        echo "<td>$msg_id</td>";
        echo "<td>$fullname</td>";
        echo "<td>$email</td>";
        echo "<td>$s_phone</td>";

        echo "<td>$subject";
        echo "<td>$msg_date</td>";
        // echo "<td><a class='text-success' href='comments.php?approve=$comment_id'>Approve</a></td>";
        echo "<td><a class='text-warning' href='message.php?source=read_msg&p_id=$msg_id'>View</a></td>";
        echo "<td><a rel='$msg_id' href='javascript:viod(0)' class='delete_link text-danger'>Delete</a></td>";
        // echo "<td><a class='text-danger' href='comments.php?delete=$comment_id'>Delete</a></td>";
        echo "</tr>";
      }


       ?>

    </tbody>
  </table>
  <?php

  if (isset($_GET['delete'])) {
    $msg_id = $_GET['delete'];

    $query = "DELETE FROM messages WHERE msg_id = $msg_id ";
    $delete_query_msgs = mysqli_query($connection, $query);

    if ($delete_query_msgs) {
      header("Location: message.php");
    } else {
      die("Unable to delete comment" . mysqli_error($connection));
    }
  }
   ?>

   <script>

     $(document).ready(function(){

       $(".delete_link").on('click', function(){

         var id = $(this).attr("rel");

         var delete_url = "message.php?delete="+ id + " ";

         $(".modal_delete_link").attr("href", delete_url);

         $("#myModal").modal('show');

       });

     });

   </script>
</div>
