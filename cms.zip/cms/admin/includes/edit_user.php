<?php
if (isset($_GET['user_id'])) {
  $user_id = $_GET['user_id'];
}
$query = "SELECT * FROM users WHERE user_id = $user_id ";
$select_users_by_id = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($select_users_by_id)) {
  $user_id = $row['user_id'];
  $user_firstname = $row['user_firstname'];
  $user_lastname = $row['user_lastname'];
  $user_role = $row['user_role'];
  $username = $row['username'];
  $user_email = $row['user_email'];
  $user_password = $row['user_password'];
  // $post_content = $row['post_content'];
  // $post_comment_count = $row['post_comment_count'];
  // $post_date = $row['post_date'];
}

if (isset($_POST['edit_user'])) {
  $user_firstname = $_POST['user_firstname'];
  $user_lastname = $_POST['user_lastname'];
  $user_role = $_POST['user_role'];
  $username = $_POST['username'];
  $user_email = $_POST['user_email'];

  // $post_image = $_FILES['image']['name'];
  // $post_image_temp = $_FILES['image']['tmp_name'];

  $user_password = $_POST['user_password'];
  $user_password = md5($user_password);


  // move_uploaded_file($post_image_temp, "../images/$post_image");

  $query = "UPDATE users SET user_firstname = '$user_firstname', user_lastname = '$user_lastname', user_role = '$user_role', username = '$username', user_email = '$user_email', user_password = '$user_password' WHERE user_id = $user_id ";

  $update_query_users = mysqli_query($connection, $query);

  if ($update_query_users) {
    echo "<div class='alert alert-success'>
    <strong>User Updated Succesfully!</strong>
    </div>";
    header('Refresh:5; url=users.php');
  } else {
    echo "<div class='alert alert-danger'>
    <strong>Unsuccesful! Cannot Update User</strong>
    </div>";
  }
}
 ?>
 <h1 class="page-header">
     Add Users
     <small>admin</small>
 </h1>
<form action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" name="user_firstname" class ="form-control" value="<?php echo $user_firstname; ?>" required>
  </div>

  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" name="user_lastname" class ="form-control" value="<?php echo $user_lastname; ?>" required>
  </div>

  <div class="form-group">
    <label for="user_role">User Role</label>
    <br>
    <select class="form-control" name="user_role">
      <option value="<?php echo $user_role; ?>"><?php echo $user_role; ?></option>
      <?php
      if ($user_role == 'admin') {
        echo "<option value='subscriber'>Subscriber</option>";
      } else {
        echo "<option value='admin'>Admin</option>";
      }
       ?>


    </select>
  </div>

  <div class="form-group">
    <label for="user">Username</label>
    <input type="text" name="username" class ="form-control" value="<?php echo $username; ?>" required>
  </div>

  <div class="form-group">
    <label for="email">User Email</label>
    <input type="email" name="user_email" class ="form-control" value="<?php echo $user_email ?>" required>
  </div>

  <!-- <div class="form-group">
    <label for="post_image">Post Image</label>
    <input type="file" name="image">
  </div> -->

  <div class="form-group">
    <label for="pass">User Password</label>
    <input type="password" name="user_password" class="form-control" value="<?php echo $user_password; ?>" required>
  </div>

    <div class="form-group">
    <input type="submit" name="edit_user" class="btn btn-primary" value="Update User">
  </div>
</form>
