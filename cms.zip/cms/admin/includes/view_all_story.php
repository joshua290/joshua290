
<h1 class="page-header">
    All Posts
    <small><?php echo $_SESSION['username']; ?></small>
</h1>
<br>
<?php include("delete_modal.php"); ?>
<div class="table-responsive">
  <table class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>ID</th>
        <th>Author</th>
        <th>Post title</th>
        <th>Image</th>
        <th>Tags</th>
        <th>Email</th>
        <th>Status</th>
        <th>Date</th>
        <th>View post</th>
        <th>Action</th>
        <th>...</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $query = "SELECT * FROM story ORDER BY story_id DESC ";
      $story_query = mysqli_query($connection, $query);

      while ($row = mysqli_fetch_assoc($story_query)) {
        $story_id = $row['story_id'];
        $story_author = $row['story_author'];
        $story_title = $row['story_title'];
        $story_image = $row['story_image'];
        $story_tags = $row['story_tags'];
        $story_email = $row['story_email'];
        $story_date = $row['story_date'];
        $story_contents = $row['story_content'];

        echo "<tr>";
        echo "<td>$story_id</td>";
        echo "<td>$story_author</td>";
        echo "<td>$story_title</td>";



        echo "<td><img src='../images/$story_image' width='100px' class='img-responsive' alt='images'></td>";
        echo "<td>$story_tags</td>";
        echo "<td>$story_email</td>";
        echo "<td>Unapproved</td>";
        echo "<td>$story_date</td>";
        echo "<td><a class='text-primary' href='story.php?source=read_story&p_id=$story_id'>View post</a></td>";
        echo "<td><a class='text-success' href='story.php?source=edit_story&p_id=$story_id'>Edit</a></td>";
        echo "<td><a rel='$story_id' href='javascript:viod(0)' class='delete_link text-danger'>Delete</a></td>";
        // echo "<td><a onClick=\"javascript: return confirm('Are you sure you want to delete this post');\"class='text-danger' href='posts.php?delete=$post_id'>Delete</a></td>";
        echo "</tr>";
      }


       ?>

    </tbody>
  </table>
  <?php
  if (isset($_GET['delete'])) {
    $story_id = $_GET['delete'];

    $query = "DELETE FROM story WHERE story_id = $story_id ";
    $delete_query_post = mysqli_query($connection, $query);

    if ($delete_query_post) {
      header("Location: story.php");
    } else {
      die("Unable to delete post" . mysqli_error($connection));
    }
  }
   ?>

   <script>

     $(document).ready(function(){

       $(".delete_link").on('click', function(){

         var id = $(this).attr("rel");

         var delete_url = "story.php?delete="+ id + " ";

         $(".modal_delete_link").attr("href", delete_url);

         $("#myModal").modal('show');

       });

     });

   </script>
</div>
