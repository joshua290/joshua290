<?php
if (isset($_GET['p_id'])) {
  $the_story_id = $_GET['p_id'];
}
$query = "SELECT * FROM story WHERE story_id = $the_story_id ";
$select_msgs_by_id = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($select_msgs_by_id)) {
  $story_id = $row['story_id'];
  $story_author = $row['story_author'];
  $email = $row['story_email'];
  $story_tags = $row['story_tags'];
  $story_content = $row['story_content'];
  $story_date = $row['story_date'];
  $story_title = $row['story_title'];

}
?>

<div class="container-fluid">
  <div class="tab-content">
    <div class="tab-pane active">
      <div class="row">
        <div class="col-md-4">
          <div class="panel panel-default panel-fill">
            <div class="panel-heading">
              <h3 class="panel-title">Story Details</h3>
            </div>

            <div class="panel-body">
              <div class="m-b-20">
                <strong>Story Author</strong>
                <br>
                <p class="text-muted"><?= $story_author ?></p>
              </div>

              <div class="m-b-20">
                <strong>E-mail</strong>
                <br>
                <p class="text-muted"><?= $email ?></p>
              </div>

              <div class="m-b-20">
                <strong>Phone Number</strong>
                <br>
                <p class="text-muted"><?php echo "NIL"; ?></p>
              </div>

              <div class="m-b-20">
                <strong>Date</strong>
                <br>
                <p class="text-muted"><?= $story_date ?></p>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-8">
          <div class="panel panel-default panel-fill">
            <div class="panel-heading">
              <h3 class="panel-title">Public Story</h3>
            </div>
            
            <div class="panel-body">
              <h4 class="font-14 mb-3 text-uppercase text-center"><?= $story_title ?></h4>
              <p><?= format_text($story_content) ?></p>
            </div>
          </div>
        </div>




      </div>
    </div>
  </div>
</div>
