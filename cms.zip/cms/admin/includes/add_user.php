<?php
if (isset($_POST['create_user'])) {
  $user_firstname = $_POST['user_firstname'];
  $user_lastname = $_POST['user_lastname'];
  $user_role = $_POST['user_role'];
  $username = $_POST['username'];
  $user_email = $_POST['user_email'];

  // $post_image = $_FILES['image']['name'];
  // $post_image_temp = $_FILES['image']['tmp_name'];

  $user_password = $_POST['user_password'];
  $user_password = md5($user_password);


  // move_uploaded_file($post_image_temp, "../images/$post_image");

  $query = "INSERT INTO users(user_firstname, user_lastname, user_role, username, user_email, user_password) ";
  $query .= "VALUES('$user_firstname', '$user_lastname', '$user_role', '$username', '$user_email', '$user_password') ";

  $create_users_query = mysqli_query($connection, $query);

  if ($create_users_query) {
    echo "<div class='alert alert-success'>";
    echo "<strong>User Added Succesfully!</strong>";
    echo "</div>";
    header('Refresh:5; url=users.php');
  } else {
    echo "<div class='alert alert-danger'>";
    echo "<strong>Unsuccesful! Cannot Add User</strong>";
    echo "</div>";
  }
}
 ?>
 <h1 class="page-header">
     Add Users
     <small>Admin</small>
 </h1>
<form action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" name="user_firstname" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" name="user_lastname" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="user_role">User Role</label>
    <br>
    <select class="form-control" name="user_role">
      <option value="subscriber">Select option</option>
      <option value="admin">Admin</option>
      <option value="subscriber">Subscriber</option>
    </select>
  </div>

  <div class="form-group">
    <label for="user">Username</label>
    <input type="text" name="username" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="email">User Email</label>
    <input type="email" name="user_email" class ="form-control" required>
  </div>

  <!-- <div class="form-group">
    <label for="post_image">Post Image</label>
    <input type="file" name="image">
  </div> -->

  <div class="form-group">
    <label for="pass">User Password</label>
    <input type="password" name="user_password" class="form-control" required>
  </div>

    <div class="form-group">
    <input type="submit" name="create_user" class="btn btn-primary" value="Add User">
  </div>
</form>
