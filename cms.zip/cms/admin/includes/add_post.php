<?php

if (isset($_POST['create_post'])) {
  $post_title = escapeString($_POST['post_title']);
  $post_category_id = escapeString($_POST['post_category_id']);
  $post_author = escapeString($_POST['post_author']);
  $post_status = escapeString($_POST['post_status']);

  $post_image = $_FILES['image']['name'];
  $post_image_temp = $_FILES['image']['tmp_name'];

  $post_tags = escapeString($_POST['post_tags']);
  $post_content = escapeString($_POST['post_content']);
  $post_date = date('d-m-Y');

  move_uploaded_file($post_image_temp, "../images/$post_image");

  if (!empty($post_title) && !empty($post_category_id) && !empty($post_author) && !empty($post_status) && !empty($post_image) && !empty($post_tags) && !empty($post_content)) {
    $query = "INSERT INTO posts(post_category_id, post_title, post_author, post_date, post_image, post_content, post_tags, post_status) ";
    $query .= "VALUES($post_category_id, '$post_title', '$post_author', now(), '$post_image', '$post_content', '$post_tags', '$post_status') ";

    $create_posts_query = mysqli_query($connection, $query);

    if ($create_posts_query) {
      echo "<div class='alert alert-success'>
      <strong>Post Published Succesfully!</strong>
      </div>";
      header('Refresh:5; url=posts.php');
    } else {
      echo "<div class='alert alert-danger'>
      <strong>Unsuccesful! Post did not Publish</strong>
      </div>";
    }
  }

}
 ?>
 <h1 class="page-header">
     Add Post
     <small><?php echo $_SESSION['username']; ?></small>
 </h1>

<form action="" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <label for="title">Post Title</label>
    <input type="text" name="post_title" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="post_category">Post Category ID</label>
    <br>
    <select class="form-control" name="post_category_id">
      <?php
      $query = "SELECT * FROM categories ";
      $select_categories = mysqli_query($connection, $query);

      if (!$select_categories) {
        die("unable to read categories " . mysqli_error($connection));
      }

      while ($row =mysqli_fetch_assoc($select_categories)) {
        $cat_id = $row['cat_id'];
        $cat_title = $row['cat_title'];

        echo "<option value='$cat_id'>$cat_title</option>";
      }
       ?>

    </select>
  </div>

  <div class="form-group">
    <label for="post_author">Post Author</label>
    <input type="text" name="post_author" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="post_status">Post Status</label>
    <select class="form-control" name="post_status">
      <option value="published">Publish Post</option>
      <option value="draft">Draft</option>
    </select>
  </div>

  <div class="form-group">
    <label for="post_image">Post Image</label>
    <input type="file" name="image" required>
  </div>

  <div class="form-group">
    <label for="post_tags">Post Tags</label>
    <input type="text" name="post_tags" class ="form-control" required>
  </div>

  <div class="form-group">
    <label for="post_content">Post Content</label>
    <textarea name="post_content" class="form-control" rows="10" cols="30" required></textarea>
  </div>

    <div class="form-group">
    <input type="submit" name="create_post" class="btn btn-primary" value="Add Post">
  </div>
</form>
