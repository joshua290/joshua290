<?php ob_start(); ?>
<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>

<?php


function test_input($data) {
  global $connection;
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  $data = mysqli_real_escape_string($connection, $data);
  return $data;
}

function postStory() {
  global $connection;
  $story_titleErr = $story_authorErr = $story_emailErr = $story_tagsErr = $story_contentErr = "";
  if (isset($_POST['submit'])) {
    $story_title = test_input($_POST['story_title']);
    $story_author = test_input($_POST['story_author']);

    $story_tags = test_input($_POST['story_tags']);
    $story_content = test_input($_POST['story_content']);
    $story_date = date('d-m-Y');

    $story_image = $_FILES['story_image']['name'];
    $story_image_temp = $_FILES['story_image']['tmp_name'];
    $story_email = test_input($_POST['story_email']);

    move_uploaded_file($story_image_temp, "images/$story_image");

    if (empty($story_title)) {
      $story_titleErr = "Post title is required!";
    }
    if (empty($story_author)) {
      $story_authorErr = "Post author is required!";
    }
    if (empty($story_email)) {
      $Story_emailErr = "Valid E-mail is required!";
    } else {
      if (!filter_var($story_email, FILTER_VALIDATE_EMAIL)) {
        $story_emailErr = "Invalid Email address format!";
        $story_email = "";
      }
    }
    if (empty($story_tags)) {
      $story_tagsErr = "Post tags is required!";
    }
    if (empty($story_content)) {
      $story_contentErr = "Fill in your Story!";
    }


    if (!empty($story_title) && !empty($story_author) && !empty($story_email) && !empty($story_tags) && !empty($story_content)) {
      $query = "INSERT INTO story(story_title, story_author, story_tags, story_image, story_status, story_content, story_date, story_email) VALUES('$story_title', '$story_author', '$story_tags', '$story_image', 'unapproved', '$story_content', now(), '$story_email') ";
      $story_query = mysqli_query($connection, $query);

      if ($story_query) {
        echo "<div class='alert alert-success'>
        <strong>Story sent Succesfully! <br> Awaiting Approval</strong>
        </div>";
      } else {
        echo "<div class='alert alert-danger'>
        <strong class='text-center'>Message not sent</strong>
        </div>";
      }
    }



  }

}

 ?>


    <!-- Navigation -->

    <?php  include "includes/navigation.php"; ?>


    <!-- Page Content -->
    <div class="container">

<section id="login">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
            <!-- <div class="col-xs-6 col-xs-offset-3"> -->
              <div class="form-wrap">
                <h1 class="text-center mb-5">Post Story</h1>
                <hr>
                <br>
                    <form class="mt-5" role="form" action="" method="post" enctype="multipart/form-data">
                      <div class="form-group">
                         <label for="fname" class="sr-only">Story Title</label>
                         <?php postStory(); ?>
                         <input type="text" name="story_title" id="fname" class="form-control" placeholder="Post Title" value="<?php if (isset($story_title)) {
                           echo $story_title;
                         } ?>">
                         <span class="text-danger"><?php if (isset($story_titleErr)) {
                           echo $story_titleErr;
                         } ?></span>
                     </div>
                     <div class="form-group">
                        <label for="phone" class="sr-only">Post Author</label>
                        <input type="text" name="story_author" id="phone" class="form-control" placeholder="Post Author" value="<?php if (isset($story_author)) {
                          echo $story_author;
                        } ?>">
                        <span class="text-danger"><?php if (isset($story_authorErr)) {
                          echo $story_authorErr;
                        } ?></span>
                    </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Post Email</label>
                            <input type="email" name="story_email" id="email" class="form-control" placeholder="somebody@example.com" value="<?php if (isset($story_email)) {
                              echo $story_email;
                            } ?>">
                            <span class="text-danger"><?php if (isset($story_emailErr)) {
                              echo $story_emailErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="lsname" class="sr-only">Story Tags</label>
                            <input type="text" name="story_tags" id="lsname" class="form-control" placeholder="Story Tags" value="<?php if (isset($story_tags)) {
                              echo $story_tags;
                            }  ?>">
                            <span class="text-danger"><?php if (isset($story_tagsErr)) {
                              echo $story_tagsErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="lsimg" class="sr-only">Story Image</label>
                            <input type="file" name="story_image" id="lsimg" class="form-control">

                        </div>
                        <div class="form-group">
                            <label for="password" class="sr-only">Story Content</label>
                            <textarea name="story_content" class="form-control" rows="8" cols="80" placeholder="Write your Story here"><?php if (isset($story_content)) {
                              echo $story_content;
                            } ?></textarea>
                            <span class="text-danger"><?php if (isset($story_contentErr)) {
                              echo $story_contentErr;
                            } ?></span>
                        </div>

                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Submit Story">
                    </form>

                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->

</section>

        <hr>



<?php include "includes/footer.php";?>
