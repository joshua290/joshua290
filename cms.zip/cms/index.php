<?php ob_start(); ?>
<?php session_start(); ?>
<?php include("includes/db.php"); ?>
<?php
if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header("location: login.php");
  }
 ?>
<?php include("includes/header.php"); ?>

    <!-- Navigation -->
    <?php include("includes/navigation.php"); ?>

      <div class="jumbotron text-center banner" style="margin-top: -20px; background-image: linear-gradient(to left, rgba(6,6, 6, 0.46),rgba(0,0,0, 1)),url(images/ukwu.jpg); background-size: cover; height:300px;">
        <h1>My First Bootstrap page</h1>
        <p>This is some text, resize this responsive page to see the effect</p>
      </div>



    <!-- Page Content -->
    <div class="container">
      <?php include("includes/story.php"); ?>

        <div class="row">


            <!-- Blog Entries Column -->
            <div class="col-md-8">
              <h1 class="page-header">
                  Latest Info
                  <small>Daily</small>
              </h1>
              <?php
              $results_per_page = 5;

              // find the total number of results stored in the database

              // if (isset($_GET['page'])) {
              //   $page = $_GET['page'];
              // } else {
              //   $page = "";
              // }
              //
              // if ($page = "" || $page = 1) {
              //   $page_1 = 0;
              // } else {
              //   $page_1 = ($page_1 * 5) - 5;
              // }


              $post_query_count = "SELECT * FROM posts WHERE post_status = 'published' ";
              $find_query_count = mysqli_query($connection, $post_query_count);
              $number_of_result = mysqli_num_rows($find_query_count);

              // determine the total number of pages available
              $number_of_page = ceil($number_of_result / $results_per_page);

              //determine which page number visitor is currrently on
              if (!isset($_GET['page'])) {
                $page = 1;
              } else {
                $page = $_GET['page'];
              }
              // determine the sql limit starting numberfor the results on the displaying page
              $page_first_result = ($page - 1) * $results_per_page;

              $query = "SELECT * FROM posts WHERE post_status = 'published' ORDER BY post_id DESC LIMIt $page_first_result, $results_per_page ";
              $query_post = mysqli_query($connection,$query);

              while ($row = mysqli_fetch_assoc($query_post)) {
                $post_id = $row['post_id'];
                $post_title = $row['post_title'];
                $post_author = $row['post_author'];
                $post_date   = $row['post_date'];
                $post_image = $row['post_image'];
                $post_content = substr($row['post_content'], 0, 200);
                ?>

                <!-- First Blog Post -->
                <h2>

                    <a href="post.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title; ?></a>
                </h2>
                <p class="lead">
                    by <a href="author_posts.php?author=<?php echo $post_author; ?>&p_id=<?php echo $post_id; ?>"><?php echo $post_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post_date; ?></p>
                <hr>
                <a href="post.php?p_id=<?php echo $post_id; ?>"><img class="img-responsive" src="images/<?php echo $post_image; ?>" width="500"  height="200" alt="Blog Image not Generated"></a>
                <hr>
                <p><?php echo $post_content; ?></p>
                <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>

            <?php } ?>


                <!-- Pager -->
                <ul class="pager">
                  <?php
                  for ($i = 1; $i <= $number_of_page; $i++) {
                    if ($i == $page) {
                      echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";
                    } else {
                      echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
                    }

                  }
                   ?>
                    <!-- <li class="previous">
                        <a href="#">&larr; Older</a>
                    </li>
                    <li class="next">
                        <a href="#">Newer &rarr;</a>
                    </li> -->
                </ul>

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include("includes/sidebar.php"); ?>

        </div>
        <!-- /.row -->

        <hr>

      <?php include("includes/footer.php"); ?>
