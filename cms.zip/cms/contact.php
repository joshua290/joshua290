<?php ob_start(); ?>
<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>

<?php
$nameErr = $phoneErr = $emailErr = $subjectErr = $bodyErr = "";

function test_input($data) {
  global $connection;
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  $data = mysqli_real_escape_string($connection, $data);
  return $data;
}

if (isset($_POST['submit'])) {
  $fullname = test_input($_POST['fname']);
  $s_phone = test_input($_POST['phone']);
  $email = test_input($_POST['email']);
  $subject = test_input($_POST['subject']);
  $msg_body = test_input($_POST['body']);
  $msg_date = date('d-m-Y');

  if (empty($fullname)) {
    $nameErr = "Full name is required!";
  }
  if (empty($s_phone)) {
    $phoneErr = "Valid Phone number is required!";
  }
  if (empty($email)) {
    $emailErr = "Valid E-mail is required!";
  } else {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid Email address format!";
      $email = "";
    }
  }
  if (empty($subject)) {
    $subjectErr = "Subject field is required!";
  }
  if (empty($msg_body)) {
    $bodyErr = "Fill in your message!";
  }


  if (!empty($fullname) && !empty($s_phone) && !empty($email) && !empty($subject) && !empty($msg_body)) {
    $query = "INSERT INTO messages(full_name, phone_num, msg_email, msg_subject, msg_body, msg_date) VALUES('$fullname', '$s_phone', '$email', '$subject', '$msg_body', now()) ";
    $contact_query = mysqli_query($connection, $query);

    if ($contact_query) {
      echo "<div class='alert alert-success'>
      <strong>Message sent Succesfully!</strong>
      </div>";
    } else {
      echo "<div class='alert alert-danger'>
      <strong class='text-center'>Message not sent</strong>
      </div>";
    }
  }



}
 ?>


    <!-- Navigation -->

    <?php  include "includes/navigation.php"; ?>


    <!-- Page Content -->
    <div class="container">

<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1 class="text-center mb-5">Contact Us</h1>
                <hr>
                <br>
                    <form class="mt-5" role="form" action="" method="post" id="login-form" autocomplete="off">
                      <div class="form-group">
                         <label for="fname" class="sr-only">Full Name</label>
                         <input type="text" name="fname" id="fname" class="form-control" placeholder="Your Full Name" value="<?php if (isset($fullname)) {
                           echo $fullname;
                         } ?>">
                         <span class="text-danger"><?php if (isset($nameErr)) {
                           echo $nameErr;
                         } ?></span>
                     </div>
                     <div class="form-group">
                        <label for="phone" class="sr-only">Phone Number</label>
                        <input type="number" name="phone" id="phone" class="form-control" placeholder="Valid Phone Number" value="<?php if (isset($s_phone)) {
                          echo $s_phone;
                        } ?>">
                        <span class="text-danger"><?php if (isset($phoneErr)) {
                          echo $phoneErr;
                        } ?></span>
                    </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com" value="<?php if (isset($email)) {
                              echo $email;
                            } ?>">
                            <span class="text-danger"><?php if (isset($emailErr)) {
                              echo $emailErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="lsname" class="sr-only">Subject</label>
                            <input type="text" name="subject" id="lsname" class="form-control" placeholder="Enter your Subject" value="<?php if (isset($subject)) {
                              echo $subject;
                            }  ?>">
                            <span class="text-danger"><?php if (isset($subjectErr)) {
                              echo $subjectErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="password" class="sr-only">Message</label>
                            <textarea name="body" class="form-control" rows="8" cols="80" placeholder="Write your message here"><?php if (isset($msg_body)) {
                              echo $msg_body;
                            } ?></textarea>
                            <span class="text-danger"><?php if (isset($bodyErr)) {
                              echo $bodyErr;
                            } ?></span>
                        </div>

                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Send Message">
                    </form>

                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>

        <hr>



<?php include "includes/footer.php";?>
