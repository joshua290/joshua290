-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2021 at 06:37 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(29, 'php 7.0'),
(30, 'python 3.5'),
(32, 'java 8.0'),
(33, 'Entertainment'),
(34, 'javascript 5.0');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(3) NOT NULL,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(9, 5, 'iloh', 'iloh@ilog.com', 'nice work of php', 'approve', '2020-11-09'),
(11, 9, 'ikejis', 'ikejis22@gmail.com', 'beautiful baby', 'Unapproved', '2020-11-17'),
(14, 9, 'ikejis', 'ikejis22@gmail.com', 'beautiful baby', 'Unapproved', '2020-11-17'),
(15, 0, 'anonymous', 'hello34@gmail.com', 'ddddddddddddddddd', 'Unapproved', '2020-12-09'),
(16, 12, 'hey', 'hey23@gmail.com', 'nsnsn sns', 'Unapproved', '2020-12-09'),
(17, 12, 'hey', 'hey23@gmail.com', 'nsnsn sns', 'Unapproved', '2020-12-09'),
(18, 12, 'hey', 'hey23@gmail.com', 'nsnsn sns', 'Unapproved', '2020-12-09'),
(19, 12, 'ego amaka', 'egoamaka22@gmail.com', 'ego is good', 'Unapproved', '2020-12-09'),
(20, 8, 'railway', 'railings22@gmail.com', 'jdsjsj sjsjs snnssn', 'Unapproved', '2020-12-09'),
(21, 8, 'railway', 'railings22@gmail.com', 'jdsjsj sjsjs snnssn', 'Unapproved', '2020-12-09'),
(22, 8, 'railway', 'railings22@gmail.com', 'jdsjsj sjsjs snnssn', 'Unapproved', '2020-12-09'),
(23, 9, 'emmanuel', 'ema23@gmail.com', 'nsnns snsnsns nsn', 'Unapproved', '2020-12-09'),
(24, 9, 'emmanuel', 'ema23@gmail.com', 'nsnns snsnsns nsn', 'Unapproved', '2020-12-09'),
(25, 13, 'nkechi', 'helloqueen@gmail.com', 'amaka ekwo', 'Unapproved', '2020-12-18'),
(26, 13, 'nkechi', 'helloqueen@gmail.com', 'amaka ekwo', 'approve', '2020-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `msg_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone_num` varchar(255) NOT NULL,
  `msg_email` varchar(255) NOT NULL,
  `msg_subject` varchar(255) NOT NULL,
  `msg_body` varchar(255) NOT NULL,
  `msg_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `full_name`, `phone_num`, `msg_email`, `msg_subject`, `msg_body`, `msg_date`) VALUES
(4, 'emeka amarachi', '2347064283203', 'emeka20@gmail.com', 'business strategy', 'Our team at West Courier Express and Logistics services gives you a competitive edge by supporting you with a team entirely focused on advanced technology partnered with years of logistics experience to facilitate seamless shipping operations. We work to ', '2020-12-07'),
(6, 'ikiwsns sdjqwnw', '233333333333333333', 'hhshs222@gmail.com', 'nsndndn dndndn', 'dmdmdmdm dmdmdm dmdmdmd', '2020-12-07');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(3) NOT NULL,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` int(11) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `post_views_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_comment_count`, `post_status`, `post_views_count`) VALUES
(4, 29, 'iloh joshuas', 'good wills', '2020-11-10', 'FB_IMG_1545259515322.jpg', 'hello every one this post have been updated and the picture changed and working Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\n\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nhello every one this post have been updated and the picture changed and working Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\n\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.', 'ballers', 9, 'published', 1),
(5, 30, 'hello world', 'luke shaw', '2020-11-10', 'FB_IMG_1542225760735.jpg', 'hello why are you not sending Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\n\r\nhello why are you not sending Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.', 'wellman', 4, 'published', 3),
(6, 32, 'chukas iloh', 'chigozie chukas', '2020-11-10', 'FB_IMG_1546643974433.jpg', 'Stephen was one of the seven deacons appointed by the apostles to help look after the poor and the needy in the church. Stephen was full of the Holy Spirit and soon he started preaching the Gospel of Jesus Christ. The Holy Spirit inspired him and gave him courage in preaching the Gospel, and he argued successfully with the opponents of the church. The success of Stephen got him into trouble with his enemies. They made false accusation against him saying that he spoke against Moses and God. Stephen was arrested and brought before the Jewish Council. Some worthless people were bribed to testify falsely against him. They said he spoke against the Holy Temple and the Law. The high priest asked Stephen if the charges were true and Stephen was able to defend himself with the help of the Holy Spirit.\r\n', 'family', 4, 'published', 3),
(7, 30, 'my new blog', 'programmer joshie', '2020-12-10', 'FB_IMG_1547413179292.jpg', 'them dey para oh, angry mob dem killing barawo, back in aba oh dem burn the boy dem do am like nama oh. Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\n\r\nhello why are you not sending Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.', 'blog, post, runs', 13, 'published', 0),
(8, 34, 'my post', 'aurthodox', '2020-12-10', 'FB_IMG_1546812305584.jpg', 'Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\n\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nhello why are you not sending Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus. Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.\r\nCras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.', 'road, railway, rails,trails', 15, 'published', 19),
(9, 30, 'alert post', 'Alert mark', '2020-12-10', 'IMG_20170127_161231.jpg', 'four types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals \r\n\r\nfour types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals ', 'alert, children', 8, 'published', 21),
(10, 29, 'jeje post', 'Alert mark', '2020-12-10', 'IMG_20180825_154454_826.JPG', 'content come  four types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals \r\nfour types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals ', 'blog, entertainment', 0, 'published', 3),
(11, 29, 'Absu', 'authordox', '2020-12-10', 'IMG_20161215_112553.jpg', 'four types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals\r\n \r\nfour types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals ', 'Absu', 0, 'published', 9),
(12, 33, 'eat post', 'Alert mark', '2020-12-10', 'Capture.PNG', 'four types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals ', 'covid19, corona', 4, 'published', 77),
(13, 34, 'Ahaiwe prince', 'prince ahaiwe', '2020-12-10', 'IMG_20170806_133520.jpg', 'four types of grammers 1) type 0 (unrestricted grammar) and it includes all the formal grammars 2)type 1 grammers(context grammers)they generates the context sensitive languages 3)type2 grammers(context-free grammers, they generates the context free languages) 4) type 3 grammers(regular grammers)they generate regular languages  Type 0(unrestricted) - this grammer genertes all languages that can be recongnized by a turing machines, this languages are also called recursive enumarable language  note: this is diff from recursive lang which can be discided as an always haulting turing machine  S-aba     Type 1: this grammers have rules of the form alphaA3.....AlphaAbeta 	with A being a non terminal and alpha beta strings of terminals', 'programs, betshop', 2, 'published', 11);

-- --------------------------------------------------------

--
-- Table structure for table `story`
--

CREATE TABLE `story` (
  `story_id` int(11) NOT NULL,
  `story_post_id` int(11) NOT NULL,
  `story_title` varchar(255) NOT NULL,
  `story_author` varchar(255) NOT NULL,
  `story_tags` varchar(255) NOT NULL,
  `story_image` varchar(255) NOT NULL,
  `story_status` varchar(255) NOT NULL,
  `story_content` varchar(255) NOT NULL,
  `story_date` date NOT NULL,
  `story_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `story`
--

INSERT INTO `story` (`story_id`, `story_post_id`, `story_title`, `story_author`, `story_tags`, `story_image`, `story_status`, `story_content`, `story_date`, `story_email`) VALUES
(1, 0, 'okeke', 'amarachi', 'house', '1941400_1423567854597917_617423174783892015_o.jpg', 'unapproved', 'snsns snsnsns snns', '2020-12-20', 'amara222@gmail.com'),
(3, 0, 'story maker', 'kinkel', 'php', '20151127_125607-1.jpg', 'unapproved', 'nndf fnfnfn fnfnfn', '2020-12-22', 'kinkel222@gmail.com'),
(4, 0, 'story maker', 'kinkel', 'php', '20151127_125607-1.jpg', 'unapproved', 'nndf fnfnfn fnfnfn', '2020-12-22', 'kinkel222@gmail.com'),
(5, 0, 'story maker', 'kinkel', 'php', '20151127_125607-1.jpg', 'unapproved', 'nndf fnfnfn fnfnfn', '2020-12-22', 'kinkel222@gmail.com'),
(6, 0, 'story maker', 'kinkel', 'php', '20151127_125607-1.jpg', 'unapproved', 'nndf fnfnfn fnfnfn', '2020-12-22', 'kinkel222@gmail.com'),
(7, 0, 'story maker', 'kinkel', 'php', '20151127_125607-1.jpg', 'unapproved', 'nndf fnfnfn fnfnfn', '2020-12-22', 'kinkel222@gmail.com'),
(9, 0, 'hello', 'arthur', 'mykin', '1506847724768.jpg', 'unapproved', 'story by lanes', '2021-01-10', 'arthur22@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(3) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) NOT NULL DEFAULT '$2y$10$iusesomecrazystrings22'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `user_password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randSalt`) VALUES
(45, 'mick', '2ea7d215f8c4de40d66de19c4a5f07ab', 'kinkel mick', 'mick', 'mick2@gmail.com', '', 'admin', '$2y$10$iusesomecrazystrings22'),
(46, 'echo 222', '0ac55400bfb0e0634bfcd08540acf848', 'ego', 'amaka', 'dhdjdj@djddj.djdjd', '', 'subscriber', '$2y$10$iusesomecrazystrings22');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL,
  `session_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `story`
--
ALTER TABLE `story`
  ADD PRIMARY KEY (`story_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `story`
--
ALTER TABLE `story`
  MODIFY `story_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
