<?php ob_start(); ?>
<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>

<?php
$usernameErr = $emailErr = $firstnameErr = $lastnameErr = $passwordErr = "";
$username = $email = $firstname = $lastname = $password = "";
function test_input($data)
{
  global $connection;
  $data = trim($data);
  $data = stripslashes($data);
  $data = strip_tags($data);
  $data = htmlspecialchars($data);
  $data = strtolower($data);
  $data = mysqli_real_escape_string($connection, $data);
  return $data;
}

if (isset($_POST['submit'])) {
  if (empty($_POST['username'])) {
    $usernameErr = "Username is required!";
  }else {
    $username = test_input($_POST['username']);
    if (!preg_match("/^[a-zA-Z-']*$/", $username)) {
      $usernameErr = "Only Letters and White space allowed!";
      $username = "";
    }
  }

  if (empty($_POST['email'])) {
    $emailErr = "Valid E-mail is required!";
  }else {
    $email = test_input($_POST['email']);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid Email address format!";
      $email = "";
    }
  }

  if (empty($_POST['firstname'])) {
    $firstnameErr = "first name is required!";
  }else {
    $firstname = test_input($_POST['firstname']);
  }

  if (empty($_POST['lastname'])) {
    $lastnameErr = "last name is required!";
  }else {
    $lastname = test_input($_POST['lastname']);
  }

  if (empty($_POST['password'])) {
    $passwordErr = "password is required!";
  }else {
    $password = test_input($_POST['password']);

  }

  $double_user_check = "SELECT * FROM users WHERE username='$username' OR user_email='$email' LIMIT 1 ";
  $result = mysqli_query($connection, $double_user_check);
	$user = mysqli_fetch_assoc($result);

  if ($user) { // if user exists
			if ($user['username'] === $username) {
			  $usernameErr =  "Username already exists";
        $username = "";
			}
			if ($user['user_email'] === $email) {
			  $emailErr = "Email already exists";
        $email = "";
			}
		}
  if (!empty($username) && !empty($email) && !empty($password) && !empty($firstname) && !empty($lastname)) {
    $username = mysqli_real_escape_string($connection, $username);
    $email = mysqli_real_escape_string($connection, $email);
    $password = mysqli_real_escape_string($connection, $password);

    $query = "SELECT randSalt FROM users ";
    $check_query = mysqli_query($connection, $query);
    if (!$check_query) {
      die("Query Failed" . mysqli_error($connection));
    }

    $row = mysqli_fetch_assoc($check_query);
    $salt = $row['randSalt'];

    // $password = crypt($password, $salt);
    $password = md5($password);

    $sql = "INSERT INTO users(username, user_password, user_firstname, user_lastname, user_email, user_role) VALUES('$username', '$password', '$firstname', '$lastname', '$email', 'subscriber') ";
    $create_user_sql = mysqli_query($connection, $sql);

     if ($create_user_sql) {
       echo "<div class='alert alert-success'>
       <strong>User Added Succesfully!</strong>
       </div>";

       header('Refresh:5; url=login.php');
     }
  }



}
 ?>

 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="background: #563D7C;">
     <div class="container">
         <!-- Brand and toggle get grouped for better mobile display -->
         <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>
             <a class="navbar-brand" href="#" style="color:#FFE484;">CMS</a>
         </div>
         <!-- Collect the nav links, forms, and other content for toggling -->
         <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

             <ul class="nav navbar-nav">

                 <li>
                     <a href="login.php"  style="color: #CDBFE3;">Login</a>
                 </li>

                 <li>
                     <a href="registration.php" style="color: #CDBFE3;">Sign up</a>
                 </li>

             </ul>

             <!-- search -->

             <!-- end of search -->
         </div>
         <!-- /.navbar-collapse -->
     </div>
     <!-- /.container -->
 </nav>

    <!-- Navigation -->

    <?php //include "includes/navigation.php"; ?>


    <!-- Page Content -->
    <div class="container">

<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="form-wrap">
                <h1 class="text-center">Register</h1>
                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">
                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input type="text" name="username" id="username" class="form-control" placeholder="Enter your Username" value="<?php if (isset($username)) {
                              echo $username;
                            } ?>">
                            <span class="text-danger"><?php if (isset($usernameErr)) {
                              echo $usernameErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="fsname" class="sr-only">First name</label>
                            <input type="text" name="firstname" id="fsname" class="form-control" placeholder="Enter your first name" value="<?php if (isset($firstname)) {
                              echo $firstname;
                            } ?>">
                            <span class="text-danger"><?php if (isset($firstnameErr)) {
                              echo $firstnameErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="lsname" class="sr-only">lastname</label>
                            <input type="text" name="lastname" id="lsname" class="form-control" placeholder="Enter your last name" value="<?php if (isset($lastname)) {
                              echo $lastname;
                            } ?>">
                            <span class="text-danger"><?php if (isset($lastnameErr)) {
                              echo $lastnameErr;
                            } ?></span>
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="email" id="email" class="form-control" placeholder="somebody@example.com" value="<?php if (isset($email)) {
                              echo $email;
                            } ?>">
                            <span class="text-danger"><?php if (isset($emailErr)) {
                              echo $emailErr;
                            } ?></span>
                        </div>
                        <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="password" id="key" class="form-control" placeholder="Password" value="<?php if (isset($password)) {
                              echo $password;
                            } ?>">
                            <span class="text-danger"><?php if (isset($passwordErr)) {
                              echo $passwordErr;
                            } ?></span>
                        </div>

                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Register">
                        <br>
                        <p class="text-center mt-3"> Already have an account? <a href="login.php">Login</a></p>
                    </form>

                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


        <hr>



<?php include "includes/footer.php";?>
